# add-hash
Firefox extension to add a key/value hash param to the current tab.

## Usage

1. Install the extension
2. Go to a page
3. Click the extension icon
4. The hash param will be added to the url
